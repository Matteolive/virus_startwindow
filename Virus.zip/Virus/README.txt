Welcome to the virus_startwindow wiki! Il mio virus è solo a scopo informativo è se usato male può 
creare seri danni quindi non mi assumo nessuna responsabilità su danni o cose del genere.
-
-
Welcome to the virus_startwindow wiki! My virus is for informational purposes only and if used incorrectly it can 
cause serious damage so I do not take any responsibility for damage or anything like that.
-
-
/
GRAZIE PER IL DOWNLOAD!
--------
THANK YOU FOR THE DOWNLOAD!